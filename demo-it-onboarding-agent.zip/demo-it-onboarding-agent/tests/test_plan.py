"""Offline tests of the policy engine. No AI and no Graph calls."""
import datetime as dt
import sys
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from onboard import build_plan  # noqa: E402

POLICY = yaml.safe_load((Path(__file__).resolve().parents[1] / "policy.yaml").read_text())
TODAY = dt.date(2026, 11, 3)


def req(**kw):
    base = {"first_name": "Maria", "last_name": "Jensen", "role": "data analyst",
            "start_date": "2026-11-09", "confidence": "high", "open_questions": []}
    return {**base, **kw}


def test_known_role_runs_without_human():
    plan = build_plan(req(), POLICY, TODAY)
    assert plan.needs_human == []
    assert plan.upn == "maria.jensen@example.dk"
    assert plan.device == "macbook"
    assert "INTUNE-macOS-Standard" in [g["name"] for g in plan.groups]
    assert "APP-Slack" in [g["name"] for g in plan.groups]


def test_danish_letters_in_upn():
    plan = build_plan(req(first_name="Søren", last_name="Ærø"), POLICY, TODAY)
    assert plan.upn == "soeren.aeroe@example.dk"


def test_unknown_role_stops():
    plan = build_plan(req(role="chief vibes officer"), POLICY, TODAY)
    assert any("not in policy.yaml" in q for q in plan.needs_human)


def test_low_confidence_stops():
    plan = build_plan(req(confidence="low", open_questions=["Last name missing"]), POLICY, TODAY)
    assert any("Last name missing" in q for q in plan.needs_human)


def test_past_start_date_stops():
    plan = build_plan(req(start_date="2026-10-01"), POLICY, TODAY)
    assert any("in the past" in q for q in plan.needs_human)


def test_sensitive_group_stops():
    policy = {**POLICY, "roles": {**POLICY["roles"], "finance": {"device": "macbook", "groups": [
        {"name": "Finance data", "id": "00000000-0000-0000-0000-000000000098"}]}}}
    plan = build_plan(req(role="finance"), policy, TODAY)
    assert any("sensitive" in q for q in plan.needs_human)
