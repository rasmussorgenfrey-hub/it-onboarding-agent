"""IT you just ask: "Maria starts Monday as a data analyst" -> a planned, policy-checked onboarding.

Flow:
  1. Claude turns the free-text request into a structured request (name, role, start date).
     The model only sees the request text. It gets no tenant data and no admin rights.
  2. A deterministic policy engine (policy.yaml) builds the plan. AI decides nothing here.
  3. Gates: unknown role, low confidence, open questions or sensitive groups -> stop and ask a human.
  4. Dry run by default. With --apply, the plan runs against Microsoft Graph with an app
     identity that has only the permissions listed in the README.
  5. Every step is written to an append-only audit log (JSON lines) that the SOC can ingest.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import secrets
import sys
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

import yaml

MODEL = "claude-opus-5-5"
AUDIT_LOG = Path(os.environ.get("ONBOARDING_AUDIT_LOG", "audit.jsonl"))
GRAPH = "https://graph.microsoft.com/v1.0"

REQUEST_SCHEMA = {
    "type": "object",
    "properties": {
        "first_name": {"type": "string"},
        "last_name": {"type": "string"},
        "role": {"type": "string", "description": "Job role in lower case, e.g. 'data analyst'"},
        "start_date": {"type": "string", "description": "ISO date YYYY-MM-DD"},
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
        "open_questions": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["first_name", "last_name", "role", "start_date", "confidence", "open_questions"],
    "additionalProperties": False,
}


# ---------- 1. Understand the request (AI) ----------

def parse_request(text: str, today: dt.date) -> dict:
    import anthropic

    client = anthropic.Anthropic()
    response = client.beta.messages.create(
        model=MODEL,
        max_tokens=2000,
        betas=["server-side-fallback-2026-07-01"],
        fallbacks="default",
        output_config={"effort": "low", "format": {"type": "json_schema", "schema": REQUEST_SCHEMA}},
        system=(
            "You turn IT onboarding requests into structured data. Today is "
            f"{today.isoformat()} ({today.strftime('%A')}). Resolve relative dates like 'Monday' "
            "to the next such date. If the last name, role or date is missing or ambiguous, "
            "do not guess: set confidence to low and list what a human must answer in open_questions."
        ),
        messages=[{"role": "user", "content": text}],
    )
    if response.stop_reason == "refusal":
        raise RuntimeError("Model declined the request; route it to a human.")
    return json.loads(next(b.text for b in response.content if b.type == "text"))


# ---------- 2. Build the plan (deterministic policy) ----------

@dataclass
class Plan:
    request: dict
    upn: str = ""
    groups: list[dict] = field(default_factory=list)
    device: str = ""
    needs_human: list[str] = field(default_factory=list)


def ascii_slug(s: str) -> str:
    s = s.lower().replace("æ", "ae").replace("ø", "oe").replace("å", "aa")
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]", "", s)


def build_plan(req: dict, policy: dict, today: dt.date) -> Plan:
    plan = Plan(request=req)
    plan.upn = f"{ascii_slug(req['first_name'])}.{ascii_slug(req['last_name'])}@{policy['tenant_domain']}"

    if req["confidence"] != "high" or req["open_questions"]:
        plan.needs_human.append("Request is unclear: " + "; ".join(req["open_questions"] or ["low confidence"]))

    role = policy["roles"].get(req["role"].strip().lower())
    if role is None:
        plan.needs_human.append(f"Role '{req['role']}' is not in policy.yaml. Add it in a pull request or onboard manually.")
        role = {"groups": [], "device": "unknown"}

    try:
        start = dt.date.fromisoformat(req["start_date"])
        if start < today:
            plan.needs_human.append(f"Start date {start} is in the past.")
    except ValueError:
        plan.needs_human.append(f"Start date '{req['start_date']}' is not a valid date.")

    plan.groups = policy["baseline_groups"] + role["groups"]
    sensitive = set(policy.get("sensitive_groups", []))
    for g in plan.groups:
        if g["id"] in sensitive:
            plan.needs_human.append(f"Group '{g['name']}' is sensitive and needs approval.")
    plan.device = role["device"]
    return plan


def describe(plan: Plan) -> str:
    r = plan.request
    lines = [
        f"Onboard {r['first_name']} {r['last_name']} as {r['role']}, starting {r['start_date']}",
        f"  1. Create Entra ID user {plan.upn} (disabled until start date)",
        *[f"  2. Add to group {g['name']}" for g in plan.groups],
        "  3. Issue a one-time Temporary Access Pass, valid from the start date (passwordless first sign-in)",
        f"  4. Device: {plan.device}. Ticket to IT to assign a device in Apple Business Manager / Autopilot",
    ]
    if plan.needs_human:
        lines.append("STOPPED, needs a human:")
        lines += [f"  - {q}" for q in plan.needs_human]
    return "\n".join(lines)


# ---------- 3. Audit ----------

def audit(event: str, **data) -> None:
    entry = {"ts": dt.datetime.now(dt.timezone.utc).isoformat(), "actor": "onboarding-agent", "event": event, **data}
    with AUDIT_LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


# ---------- 4. Execute (Microsoft Graph) ----------

def graph_session():
    import msal
    import requests

    app = msal.ConfidentialClientApplication(
        client_id=os.environ["ENTRA_CLIENT_ID"],
        authority=f"https://login.microsoftonline.com/{os.environ['ENTRA_TENANT_ID']}",
        client_credential=os.environ["ENTRA_CLIENT_SECRET"],  # use a certificate in production
    )
    token = app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])
    if "access_token" not in token:
        raise RuntimeError(f"Token request failed: {token.get('error_description')}")
    s = requests.Session()
    s.headers["Authorization"] = f"Bearer {token['access_token']}"
    return s


def execute(plan: Plan, policy: dict) -> None:
    s = graph_session()
    r = plan.request
    user = s.post(f"{GRAPH}/users", json={
        "accountEnabled": False,
        "displayName": f"{r['first_name']} {r['last_name']}",
        "givenName": r["first_name"], "surname": r["last_name"], "jobTitle": r["role"].title(),
        "mailNickname": plan.upn.split("@")[0], "userPrincipalName": plan.upn,
        "usageLocation": policy["usage_location"],
        # Random password nobody sees; first sign-in uses the Temporary Access Pass.
        "passwordProfile": {"forceChangePasswordNextSignIn": True, "password": secrets.token_urlsafe(24)},
    })
    user.raise_for_status()
    user_id = user.json()["id"]
    audit("user_created", upn=plan.upn, user_id=user_id)

    for g in plan.groups:
        resp = s.post(f"{GRAPH}/groups/{g['id']}/members/$ref",
                      json={"@odata.id": f"{GRAPH}/directoryObjects/{user_id}"})
        resp.raise_for_status()
        audit("group_added", upn=plan.upn, group=g["name"])

    start = f"{r['start_date']}T07:00:00Z"
    tap = s.post(f"{GRAPH}/users/{user_id}/authentication/temporaryAccessPassMethods",
                 json={"startDateTime": start, "lifetimeInMinutes": 480, "isUsableOnce": True})
    tap.raise_for_status()
    audit("tap_issued", upn=plan.upn, valid_from=start)  # the pass itself is never logged
    audit("device_ticket", upn=plan.upn, device=plan.device)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("request", help='e.g. "Maria Jensen starts Monday as a data analyst"')
    ap.add_argument("--apply", action="store_true", help="execute against Microsoft Graph (default: dry run)")
    ap.add_argument("--policy", default=Path(__file__).with_name("policy.yaml"))
    args = ap.parse_args()

    today = dt.date.today()
    policy = yaml.safe_load(Path(args.policy).read_text(encoding="utf-8"))
    req = parse_request(args.request, today)
    audit("request_parsed", request_text=args.request, parsed=req)

    plan = build_plan(req, policy, today)
    print(describe(plan))
    if plan.needs_human:
        audit("stopped_for_human", upn=plan.upn, reasons=plan.needs_human)
        return 2
    if not args.apply:
        audit("dry_run", upn=plan.upn)
        print("\nDry run. Re-run with --apply to execute.")
        return 0
    execute(plan, policy)
    print("\nDone. Every step is in", AUDIT_LOG)
    return 0


if __name__ == "__main__":
    sys.exit(main())
